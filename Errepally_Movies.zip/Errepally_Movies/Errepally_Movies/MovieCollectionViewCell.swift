//
//  MovieCollectionViewCell.swift
//  Errepally_Movies
//
//  Created by Tejaswi Maddela on 11/26/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var movieImageView: UIImageView!
    func configureCell(img: UIImage) {
        movieImageView.image = img
    }
    
}
