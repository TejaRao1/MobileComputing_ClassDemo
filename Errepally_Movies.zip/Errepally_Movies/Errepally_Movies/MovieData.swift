//
//  MovieData.swift
//  Errepally_Movies
//
//  Created by Tejaswi Maddela on 11/26/23.
//

import Foundation
import UIKit

struct Movie {
    var title: String?
    var image: UIImage?
    var releasedYear: String?
    var movieRating: String?
    var boxOffice: String?
    var moviePlot: String?
    var cast: [String]?
    
}


struct Genre {
    var category: String?
    var movies : [Movie]?
}



var scienceFiction1 = Movie(title: "Avatar the way of water", image: UIImage(named: "science1"),releasedYear: "2022",movieRating: "7.7",boxOffice: "659M",moviePlot: "Jake Sully lives with his newfound family formed on the extrasolar moon Pandora. Once a familiar threat returns to finish what was previously started, Jake must work with Neytiri and the army of the Na'vi race to protect their home.", cast: ["Sam Worthington", "Sigourney Weaver"])

var scienceFiction2 = Movie(title: "65", image: UIImage(named: "science2"),releasedYear: "2023",movieRating: "5.7",boxOffice: "200M",moviePlot: "An astronaut crash lands on a mysterious planet only to discover he's not alone.", cast: ["Adam Driver", "Chole Coleman"])

var scienceFiction3 = Movie(title: "Ant-Man and the Wasp", image: UIImage(named: "science3"),releasedYear: "2023",movieRating: "6.3",boxOffice: "509M",moviePlot: "Scott Lang and Hope Van Dyne are dragged into the Quantum Realm, along with Hope's parents and Scott's daughter Cassie. Together they must find a way to escape, but what secrets is Hope's mother hiding? And who is the mysterious Kang?", cast: ["Paul Rudd", "Michael Douglas", "Evangeline Lilly"])

var scienceFiction4 = Movie(title: "The Last Of Us", image: UIImage(named: "science4"),releasedYear: "2023",movieRating: "8.7",boxOffice: "300M",moviePlot: "After a global pandemic destroys civilization, a hardened survivor takes charge of a 14-year-old girl who may be humanity's last hope.", cast: ["Pedro Pascal", "Bella Ramsey","Anna Torv","Lamar Johnson"])

var scienceFiction5 = Movie(title: "The Mandalorian", image: UIImage(named: "science5"),releasedYear: "2019",movieRating: "8.7",boxOffice: "369M",moviePlot: "The travels of a lone bounty hunter in the outer reaches of the galaxy, far from the authority of the New Republic.", cast: ["Chris Bartlett", "Katee Sackhoff","Carl Weathers"])



var thriller1 = Movie(title: "The Night Agent", image: UIImage(named: "thriller1"),releasedYear: "2023",movieRating: "7.6",boxOffice: "150M",moviePlot: "Low-level FBI agent Peter Sutherland works in the basement of the White House manning a phone that never rings - until the night it does, propelling him into a conspiracy that leads all the way to the Oval Office.", cast: ["Gabriel Basso", "Luciane Buchanan"])

var thriller2 = Movie(title: "Obession", image: UIImage(named: "thriller2"),releasedYear: "2023",movieRating: "5.1",boxOffice: "124M",moviePlot: "William falls in love with his soon-to-be daughter in law, Anna who's trying to keep both relationships but the truth always comes to light and someone is going to be hurt.", cast: ["Ricgard Armitage", "Charlie Murphy", "Rish Shah", "Indira Varma"])

var thriller3 = Movie(title: "Florida Man", image: UIImage(named: "thriller3"),releasedYear: "2023",movieRating: "6.8",boxOffice: "109M",moviePlot: "When an ex-cop returns to his home state of Florida to find a mobster's runaway girlfriend, what should've been a quick gig turns into a wild odyssey.", cast: ["Edgar Ramirez", "Ostmara Marrero"])

var thriller4 = Movie(title: "John Wick", image: UIImage(named: "thriller4"),releasedYear: "2023",movieRating: "8.2",boxOffice: "380M",moviePlot: "John Wick uncovers a path to defeating The High Table. But before he can earn his freedom, Wick must face off against a new enemy with powerful alliances across the globe and forces that turn old friends into foes.", cast: ["Keanu Reeves", "George Georgious","Clancy Brown","Aimee Kwan"])

var thriller5 = Movie(title: "Yellowjackets", image: UIImage(named: "thriller5"),releasedYear: "2021",movieRating: "7.9",boxOffice: "149M",moviePlot: "A wildly talented high school girl soccer team becomes the (un)lucky survivors of a plane crash deep in the Canadian wilderness.", cast: ["Melanie Lynskey", "Christina Ricci","Sophie Nelisse","Steven Krueger"])


var horror1 = Movie(title: "Beau Is Afraid", image: UIImage(named: "horror1"),releasedYear: "2023",movieRating: "7.3",boxOffice: "180M",moviePlot: "Following the sudden death of his mother, a mild-mannered but anxiety-ridden man confronts his darkest fears as he embarks on an epic, Kafkaesque odyssey back home.", cast: ["Joaquin Phoenix", "Amy Ryans"])

var horror2 = Movie(title: "Renfield", image: UIImage(named: "horror2"),releasedYear: "2023",movieRating: "6.7",boxOffice: "224M",moviePlot: "Renfield, Dracula's henchman and inmate at the lunatic asylum for decades, longs for a life away from the Count, his various demands, and all of the bloodshed that comes with them.", cast: ["Nicholas Hoult", "Awkwafina", "Shohreh Aghdashloo", "Nicolas Cage"])

var horror3 = Movie(title: "The pope's Exorcist", image: UIImage(named: "horror3"),releasedYear: "2023",movieRating: "6.2",boxOffice: "201M",moviePlot: "Follow Gabriele Amorth, the Vatican's leading exorcist, as he investigates the possession of a child and uncovers a conspiracy the Vatican has tried to keep secret.", cast: ["Russell Crowe", "Alex Essoe"])

var horror4 = Movie(title: "The Walking Dead", image: UIImage(named: "horror4"),releasedYear: "2010",movieRating: "8.1",boxOffice: "214M",moviePlot: "Sheriff Deputy Rick Grimes wakes up from a coma to learn the world is in ruins and must lead a group of survivors to stay alive.", cast: ["Andrew Lincoln", "Melissa McBride"])

var horror5 = Movie(title: "Nefarious", image: UIImage(named: "horror5"),releasedYear: "2023",movieRating: "6.4",boxOffice: "253M",moviePlot: "On the day of his scheduled execution, a convicted serial killer gets a psychiatric evaluation during which he claims he is a demon, and further claims that before their time is over, the psychiatrist will commit three murders of his own.", cast: ["Sean Patrick Flanery", "Tom Ohmer","Eric Hanson"])





let genre1 = Genre(category: "Science Fiction", movies: [scienceFiction1, scienceFiction2,scienceFiction3,scienceFiction4,scienceFiction5])

let genre2 = Genre(category: "Thriller", movies: [thriller1, thriller2,thriller3,thriller4,thriller5])

let genre3 = Genre(category: "Horror", movies: [horror1, horror2,horror3,horror4,horror5])


var genreArr = [genre1,genre2,genre3]
