//
//  MoviesViewController.swift
//  Errepally_Movies
//
//  Created by Tejaswi Maddela on 11/26/23.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var movieCollectionView: UICollectionView!
    
    @IBOutlet weak var movieNameLabel: UILabel!
    
    @IBOutlet weak var movieRatingLabel: UILabel!
    
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    
    @IBOutlet weak var movieYearLabel: UILabel!
    
    @IBOutlet weak var moviePlotLabel: UILabel!
    
    @IBOutlet weak var movieCastLabel: UILabel!
    
    var moviesList: Genre?

    override func viewDidLoad() {
        super.viewDidLoad()
        movieCollectionView.delegate = self
        movieCollectionView.dataSource = self
        
        self.title = moviesList!.category
        
        movieNameLabel.text = "Movie Name : " + moviesList!.movies![0].title!
        movieRatingLabel.text = "Movie Rating : " + moviesList!.movies![0].movieRating!
        movieBoxOfficeLabel.text = "Box Office Collection : " + moviesList!.movies![0].boxOffice!
        movieYearLabel.text = "Movie Released Year : " + moviesList!.movies![0].releasedYear!
        moviePlotLabel.text = "Plot : " + moviesList!.movies![0].moviePlot!
        movieCastLabel.text = "Cast : \n\(moviesList!.movies![0].cast!.joined(separator: ", "))"

    }
    

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        (moviesList!.movies!.count)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        cell.configureCell(img: (moviesList!.movies![indexPath.row].image!))
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        movieNameLabel.text = "Movie Name : " + moviesList!.movies![indexPath.row].title!
        movieRatingLabel.text = "Movie Rating : " + moviesList!.movies![indexPath.row].movieRating!
        movieBoxOfficeLabel.text = "Box Office Collection : " + moviesList!.movies![indexPath.row].boxOffice!
        movieYearLabel.text = "Movie Released Year : " + moviesList!.movies![indexPath.row].releasedYear!
        moviePlotLabel.text = "Plot : " + moviesList!.movies![indexPath.row].moviePlot!
        movieCastLabel.text = "Cast : \n\(moviesList!.movies![indexPath.row].cast!.joined(separator: ", "))"
    }
}
