//
//  MovieCollectionViewCell.swift
//  CollectionViewDemo
//
//  Created by Errepally,Raviteja on 11/16/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var ImageViewOL: UIImageView!
    
    func AssignMovie(with movie: Movie){
        //Assigning movie to imageviewOL
        ImageViewOL.image = movie.image
    }
}
