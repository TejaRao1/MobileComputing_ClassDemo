//
//  ViewController.swift
//  CollectionViewDemo
//
//  Created by Errepally,Raviteja on 11/16/23.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        //Create a cell
        let cell = CollectionViewOL.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        //populate a cell
        cell.AssignMovie(with: movies[indexPath.row])
        //return the cell
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        TitleOL.text! = "Title : \(movies[indexPath.row].title)"
        YearsReleasedOL.text! = "Year Release : \(movies[indexPath.row].releasedYear)"
        RatingOL.text! = "Year Release : \(movies[indexPath.row].movieRating)"
        BoxOfficeOL.text! = "Year Release : \(movies[indexPath.row].boxOffice)"
    }

    @IBOutlet weak var TitleOL: UILabel!
    
    @IBOutlet weak var YearsReleasedOL: UILabel!
    
    @IBOutlet weak var RatingOL: UILabel!
    
    @IBOutlet weak var BoxOfficeOL: UILabel!
    
    @IBOutlet weak var CollectionViewOL: UICollectionView!
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
            
            CollectionViewOL.dataSource = self
            CollectionViewOL.delegate = self
    }


}

