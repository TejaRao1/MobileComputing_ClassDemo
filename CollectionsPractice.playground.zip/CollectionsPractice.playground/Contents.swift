import UIKit

var greeting = "Hello, playground"

//ARRAYS
//Creating an Array
var someInts: [Int] = []
print("SomeInts of type Int with \(someInts.count) items")
someInts.append(3)

//Creating an Array with a default value
var threeDoubles = Array(repeating: 0.0, count: 3) //It stores [0.0,0.0,0.0]
//Creating the array by adding two arrays together
var anotherThreeDoubles = Array(repeating: 2.5, count: 3)
var sixDoubles = threeDoubles+anotherThreeDoubles
print(sixDoubles)

//Creating an Array with an Array Literal
var shoppingList : [String] = ["Eggs", "Milk"]
//Accessing and modifying items
print(shoppingList.count)
if shoppingList.isEmpty{
    print("Shopping list is empty")
} else{
    print("Shopping list is not empty")
}
//Appending items to the the array
shoppingList.append("Flour")
shoppingList+=["Baking Powder"]
shoppingList+=["Chocolates","Cheese","Butter"]

//Assigning first item to a var value
var firstItem = shoppingList[0]
shoppingList[4...6] = ["Bananas", "Apples"]
shoppingList.insert("Maple", at: 0)
let maple = shoppingList.remove(at: 0)
let apples = shoppingList.removeLast()

//Iterating over an array
for item in shoppingList{
    print(item)
}

for(index, value) in shoppingList.enumerated(){
    print("Item \(index+1): \(value)")
}

//SETS
//Creating an empty set
var letters = Set<Character>()
print(letters.count)
letters.insert("a")
letters = []

//Creating a set with an array literal
var favoriteGenres : Set<String> = ["Rock", "Classical", "Hip Hop"]
//var favoriteGenres: Set = ["Rock", "Classical", "Hip Hop"]
print(favoriteGenres.count)

if favoriteGenres.isEmpty{
    print("As far as music goes, I'm not picky")
} else{
    print("I've purticular music preferences")
}
favoriteGenres.insert("Jazz")

if let removedGenre = favoriteGenres.remove("Rock"){
    print(removedGenre)
}else{
    print("I never cared for that")
}

if favoriteGenres.contains("Funk"){
    print("I am on good foot")
}else{
    print("It is tooo funky in here")
}
    
for genre in favoriteGenres{
    print(genre)
}

for genre in favoriteGenres.sorted(){
    print(genre)
}
    
//Fundamental set operations
let oddDigits: Set = [1,3,5,7,9]
let evenDigits: Set = [0,2,4,6,8]
let singleDigitPrimes: Set = [2,3,5,7]
    
print(oddDigits.union(evenDigits).sorted())
print(oddDigits.subtracting(evenDigits).sorted())
print(oddDigits.symmetricDifference(singleDigitPrimes).sorted())

//Set membership and equality
let houseAnimals:Set = ["🐶","🐱"]
let wildAnimals:Set = ["🐯","🦁","🦅","🐊","🐻‍❄️","🐶","🐱"]
let cityAnimals:Set = ["🐤","🐒","🦆"]

print(houseAnimals.isSubset(of: wildAnimals))
print(wildAnimals.isSubset(of: houseAnimals))
print(wildAnimals.isDisjoint(with: cityAnimals))

//DICTIONARIES
//Creating an empty dictionary
var namesOfIntegers:[Int:String] = [:]
namesOfIntegers[16] = "Sixteen" //Inserting a value "Sixteen" to a key 16
//Creating a dictionary with a Dictionary literal
var airports : [String: String] = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
//var airports = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
print(airports.count)

if airports.isEmpty{
    print("Airports disctionary is empty")
}else{
    print("Airports disctionary has some values")
}

airports["LHR"] = "London"
airports["LHR"] = "London Heathrow" //The value "London" changes to "London Heathrow" to the key "LHR"

if let oldValue = airports.updateValue("Dublin Airport", forKey: "DUB") {
    print("The old value for DUB was \(oldValue).")
}

if let airportName = airports["DUB"] {
    print("The name of the airport is \(airportName).")
} else {
    print("That airport isn't in the airports dictionary.")
}

airports["APL"] = "Apple International"
airports["APL"] = nil


if let removedValue = airports.removeValue(forKey: "DUB") {
    print("The removed airport's name is \(removedValue).")
} else {
    print("The airports dictionary doesn't contain a value for DUB.")
}

for (airportCode, airportName) in airports {
    print("\(airportCode): \(airportName)")
}

for airportName in airports.values {
    print("Airport name: \(airportName)")
}

let airportCodes = [String](airports.keys)
let airportNames = [String](airports.values)
