//
//  ViewController.swift
//  VowelTest
//
//  Created by Errepally,Raviteja on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TextInputOL: UITextField!
    
    @IBOutlet weak var displayOL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CheckVowelBTN(_ sender: UIButton) {
        //Read the input text and assign it to a variable
        var VowelCheck = TextInputOL.text!
        
        //Check if text has any vowels or not
        
        
        
      /** if VowelCheck.contains("a"){
            displayOL.text = "\(VowelCheck) contain vowels"
        }
            else if VowelCheck.contains("e"){
                displayOL.text = "\(VowelCheck) contain vowels"
                
                
            }
            else if VowelCheck.contains("i"){
                displayOL.text = "\(VowelCheck) contain vowels"
            }
      
            else if VowelCheck.contains("o"){
                displayOL.text = "\(VowelCheck) contain vowels"
            }
        
            else if VowelCheck.contains("u"){
                displayOL.text = "\(VowelCheck) contain vowels"
            }
        
            else{
                displayOL.text = "\(VowelCheck) doesn't contain vowels"
            }
     */
        if (VowelCheck.contains("a") || VowelCheck.contains("e") || VowelCheck.contains("i") || VowelCheck.contains("o") || VowelCheck.contains("u")){
            displayOL.text = "\(VowelCheck) contain vowels"
        }
        else{
            displayOL.text = "\(VowelCheck) doesn't contain vowels"
        }
        //If text has any vowels like a e i o u, print "original text" else print "no vowels"
    }
    
}

