//
//  ProductDescriptionViewController.swift
//  TableViewDemo
//
//  Created by Errepally,Raviteja on 11/9/23.
//

import UIKit

class ProductDescriptionViewController: UIViewController {

    @IBOutlet weak var ProductLabelOL: UILabel!
    
    var product : Product?
    override func viewDidLoad() {
        super.viewDidLoad()

        ProductLabelOL.text = "The product Name is \((product?.name)!) is  of catagory \((product?.catagory)!)"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
