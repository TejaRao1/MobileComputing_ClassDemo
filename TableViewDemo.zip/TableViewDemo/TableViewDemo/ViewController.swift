//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Errepally,Raviteja on 11/9/23.
//

import UIKit

class Product{
    
    var name : String?
    var catagory : String?
    
    init(name: String?, catagory: String?) {
        self.name = name
        self.catagory = catagory
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //returns the number of products
        return productsArray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //Create the cell
        var cell = TableViewOL.dequeueReusableCell(withIdentifier: "reusableCell" , for: indexPath)
        //populate the cell
        cell.textLabel?.text = productsArray[indexPath.row].name
        //return the cell
        return cell
        
    }
    

    @IBOutlet weak var TableViewOL: UITableView!
    
    var productsArray = [Product]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let product1 = Product(name: "MacBook Air", catagory: "Laptop")
        let product2 = Product(name: "iPhone", catagory: "Mobile")
        let product3 = Product(name: "Airpods", catagory: "Accessories")
        let product4 = Product(name: "iWatch", catagory: "Accessories")
        let product5 = Product(name: "Charger", catagory: "Accessories")
        
        productsArray.append(product1)
        productsArray.append(product2)
        productsArray.append(product3)
        productsArray.append(product4)
        productsArray.append(product5)
        
        TableViewOL.delegate = self
        TableViewOL.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if(transition == "productDetails"){
            let destination = segue.destination as! ProductDescriptionViewController
            destination.product = productsArray[(TableViewOL.indexPathForSelectedRow?.row)!]
        }
    }


}

