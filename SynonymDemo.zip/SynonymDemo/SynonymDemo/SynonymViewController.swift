//
//  SynonymViewController.swift
//  SynonymDemo
//
//  Created by Errepally,Raviteja on 11/28/23.
//

import UIKit

class SynonymViewController: UIViewController {
    
    @IBOutlet weak var WordOL: UILabel!
    
    @IBOutlet weak var SynonymOL: UILabel!
    

    var meaning : Meaning?
    override func viewDidLoad() {
        super.viewDidLoad()

        WordOL.text = "The word is is \((meaning?.word)!)"
        SynonymOL.text = "The meaning for the word is \((meaning?.synonym)!)"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
