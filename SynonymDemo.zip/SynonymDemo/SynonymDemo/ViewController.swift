//
//  ViewController.swift
//  SynonymDemo
//
//  Created by Errepally,Raviteja on 11/28/23.
//

import UIKit

class Meaning{
    
    var word : String?
    var synonym : String?
    
    init(word: String?, synonym: String?) {
        self.word = word
        self.synonym = synonym
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //returns the number of products
        return productsArray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //Create the cell
        var cell = TableViewOL.dequeueReusableCell(withIdentifier: "Word_cell" , for: indexPath)
        //populate the cell
        cell.textLabel?.text = productsArray[indexPath.row].word
        //return the cell
        return cell
        
    }
    
    
    
    
    @IBOutlet weak var TableViewOL: UITableView!
    
    
    var productsArray = [Meaning]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let word1 = Meaning(word: "Gender 👩‍👦", synonym: "The word used to differentiate people")
        let word2 = Meaning(word: "computer🖥️", synonym: "The machine used to oerform various tasks which replaced paperwork")
        let word3 = Meaning(word: "tree🌴", synonym: "the producer of various fruits and vegerables which has life")
        let word4 = Meaning(word: "love❤️", synonym: "A positive tender emotion which can be present between any number of people")
        let word5 = Meaning(word: "angry😡", synonym: "A negative unvaulantery emotion used to express rage and pain sometimes")
        
        productsArray.append(word1)
        productsArray.append(word2)
        productsArray.append(word3)
        productsArray.append(word4)
        productsArray.append(word5)
        
        TableViewOL.delegate = self
        TableViewOL.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if(transition == "wordSegue"){
            let destination = segue.destination as! SynonymViewController
            destination.meaning = productsArray[(TableViewOL.indexPathForSelectedRow?.row)!]
        }
    }


}

