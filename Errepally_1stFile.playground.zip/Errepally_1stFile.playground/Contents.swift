import UIKit
print("date - 22/08")
var greeting = "Hello, playground"
print("Teja Rao E")
print("How are you?")


print("date-24/08")
print("Hi", 10, 12.5)
var programming_language = "Swift"
print(" My favorite programming language is \(programming_language)")

//String Interpolation: This works when we want to concatinate any data types in a statement
var age = 26
print("I am \(age) years old and I will be \(26+5) years old after 5 years from now")

var name = "Teja"
print(" My name is "+name)
//print(" My name is "+name"and I am "+age "years old")-This statement throws an error as we cannot concatinate different datatypes using +. This is where we use string interpolation

print("""
Hi Teja!
How are you?
""")
//""" will make the statements print exactly the same way they are written

print("Hi all, \rWelcome to my madness")
//\r will print is used as a break command

let message : String = "Hello!"
print(message, "all")
//let is the constant variable


print("Welcome to Swift Programming language")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming language" , terminator : "-" )
//Terminator command will end the line with a specified symbol
print("Fall 2021")

print("The list of numbers are")
print(1, 2, 3, 4, 5)
print("We use separator  for the above command as below")
print(1, 2 , 3, 4, 5, separator : "$")
//A separator command is useful to separate the words using the specified symbol
print("Hey Teja", "What are you doing?","What is it?", separator :"_")


var brand = "Jio"
brand = "Airtel"
print(brand)

//Explicit declaration
var hours : Int = 12
hours = 12+hours
print(hours)


var message1 = "I am good"
print(message)
print("message")
//The later will be considered as the string as it is given in ""

var rate  = 12.5
var hrs = 10.0
print("They are paying me \(rate) per hour which makes \(rate * hrs)")
      
      
var error_msg = (code : 404 , msg : "no page found")
print(error_msg)
print(error_msg.code, terminator : ":")
print(error_msg.msg)


var axis = (x : 0, y : 0)
var point = axis
print(point)

let city = (name : "Kansas", population : 20, 000)
print(city.0)
print(city.2)
//In the above statement, the comma between 20,000 will separate the value into two and makes thethird value as 0
let (cityname, citypopulation) = (city.name, city.population)
print(cityname)
print(citypopulation)

let city = (name : "Kansas", population : 20000)
print(city.1)
