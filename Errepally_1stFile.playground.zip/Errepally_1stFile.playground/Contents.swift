import UIKit

var greeting = "Hello, playground"
print("Teja Rao E")
print("How are you?")
