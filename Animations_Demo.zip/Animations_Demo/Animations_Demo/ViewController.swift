//
//  ViewController.swift
//  Animations_Demo
//
//  Created by Errepally,Raviteja on 10/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageviewOL: UIImageView!
    
    @IBOutlet weak var happyOL: UIButton!
    
    @IBOutlet weak var sadOL: UIButton!
    
    @IBOutlet weak var angryOL: UIButton!
    
    @IBOutlet weak var animateOL: UIButton!
    
    @IBOutlet weak var showOL: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        //Move the image  view outside of the screen view
        //Similarly, move other components outside of the screen
        imageviewOL.frame.origin.x = view.frame.maxX
        happyOL.frame.origin.x = view.frame.maxX
        sadOL.frame.origin.x = view.frame.maxX
        angryOL.frame.origin.x = view.frame.maxX
        animateOL.frame.origin.x = view.frame.maxX
    }
    
    @IBAction func HappyBTN(_ sender: Any) {
        UpdateandAnimate("happy")
    }
    
    @IBAction func sadBTN(_ sender: Any) {
        UpdateandAnimate("sad")
    }
    
    @IBAction func angryBTN(_ sender: Any) {
        UpdateandAnimate("angry")
    }
    
    @IBAction func animateBTN(_ sender: Any) {
        var width = imageviewOL.frame.width
        width += 40
        
        var height = imageviewOL.frame.height
        height += 40
        
        var x = imageviewOL.frame.origin.x - 20
        var y = imageviewOL.frame.origin.y - 20
        
        //Create a rectangle objectt with larger frame
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
            self.imageviewOL.frame = largeFrame
        })
    }
    
    
    @IBAction func showBTN(_ sender: Any) {
        
        UIView.animate(withDuration: 1, animations:{
            self.imageviewOL.center.x = self.view.center.x
            self.happyOL.center.x = self.view.center.x
            self.sadOL.center.x = self.view.center.x
            self.angryOL.center.x = self.view.center.x
            self.animateOL.center.x = self.view.center.x
         
        })
        showOL.isEnabled = false
    }
    
    func UpdateandAnimate(_ imageName : String){
        //Make the current image opaque(alpha should be 0)
        UIView.animate(withDuration: 1, animations:{
            self.imageviewOL.alpha = 0
            
        })
        
        //Assign the new image with animation and make it transparent(alpha should be 1)
        UIView.animate(withDuration: 1, delay: 0.5, animations: {
            self.imageviewOL.alpha = 1
            self.imageviewOL.image = UIImage(named: imageName)
        })
    }
    }

