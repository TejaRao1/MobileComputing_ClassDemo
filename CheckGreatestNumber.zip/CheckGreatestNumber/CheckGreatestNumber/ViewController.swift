//
//  ViewController.swift
//  CheckGreatestNumber
//
//  Created by Errepally,Raviteja on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Number1OL: UITextField!
    
    
    @IBOutlet weak var Number2OL: UITextField!
    
    @IBOutlet weak var DisplayOL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func CheckBTN(_ sender: UIButton) {
        var n1 = Int(Number1OL.text!)
        var n2 = Int(Number2OL.text!)
        
        
        if(n1!>n2!){
            DisplayOL.text = "\(n1)! is greater than \(n2)"
        }
        else if(n2!>n1!){
            DisplayOL.text = "\(n2)! is greater than \(n1)"
        }
        else{
            DisplayOL.text = "\(n1)! and \(n2) are equal"
        }
    }
    
    
    
}

