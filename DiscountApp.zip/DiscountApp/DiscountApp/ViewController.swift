//
//  ViewController.swift
//  DiscountApp
//
//  Created by Errepally,Raviteja on 9/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var AmountOL: UITextField!
    
    @IBOutlet weak var DiscountOL: UITextField!
    
    @IBOutlet weak var ResultOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func CalculateBTN(_ sender: Any) {
        
    }
    func DiscCal(AmountOL: Double,DiscountOL:Double)->Double{
        var Amount = AmountOL
        var Discount = DiscountOL
        
        var PriceAfterDisc = Double(Amount-(Amount/100)*Discount)
    }
}

