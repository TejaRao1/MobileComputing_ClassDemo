//
//  StudentInfoViewController.swift
//  StudentApp
//
//  Created by Errepally,Raviteja on 11/7/23.
//

import UIKit

class StudentInfoViewController: UIViewController {

    @IBOutlet weak var StudentNameOL: UILabel!
    
    @IBOutlet weak var StudentIDOL: UILabel!
    
    @IBOutlet weak var StudentMailOL: UILabel!
    
    @IBOutlet weak var ViewCoursesBTN: UIButton!
    
    //variable created to hold the Student object we recieve from the LoginController
        var studentObj = Student()
        
        var guestUser:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if guestUser {
                    //if the user is guest we will hide all the outlets and display 'Guest User'
            StudentMailOL.isHidden = true
            StudentNameOL.text = "Name: Guest User"
            StudentIDOL.isHidden = true
            ViewCoursesBTN.isHidden = true
                    
                }else{
                    
                    //If the student is found, then we assign the values of the studentObj to the outelts
                    StudentIDOL.text = "SID: " + studentObj.sid
                    StudentMailOL.text = "Email: " + studentObj.email
                    StudentNameOL.text = "Name: " + studentObj.name
                }
                
            }
            
            override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                let transition = segue.identifier
                
                //We need to view courses of the logged in student in CourseViewController,
                // So we pass the courses from the 'studentObj' variable
                if transition == "courseSegue" {
                    let destination = segue.destination as! StudentCoursesViewController
                    
                    //we will assign the courses to 'courseArray' in the CourseViewController
                    destination.coursesArray = studentObj.courses
                }
            }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
