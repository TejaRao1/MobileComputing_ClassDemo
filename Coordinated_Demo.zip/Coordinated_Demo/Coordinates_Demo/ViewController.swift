//
//  ViewController.swift
//  Coordinated_Demo
//
//  Created by Errepally,Raviteja on 10/17/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageViewOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minX = ImageViewOL.frame.minX
        let minY = ImageViewOL.frame.minY
        print("The top left corner of the image is at \(minX),  \(minY)")
        let maxX = ImageViewOL.frame.maxX
        let maxY = ImageViewOL.frame.maxY
        print("The bottom right corner of the image is \(maxX),  \(maxY)")
        let midX = ImageViewOL.frame.midX
        let midY = ImageViewOL.frame.midY
        print("The center point of the image is \(midX),  \(midY)")
        
        //Display the image at the top left corner of the view for iphone 14 pro max
        ImageViewOL.frame.origin.x = 0
        ImageViewOL.frame.origin.y = 0
        
        //image at bottom left
        ImageViewOL.frame.origin.x = 330
        ImageViewOL.frame.origin.y = 832
        
        //image at top right
        //ImageViewOL.frame.origin.x = 0
        //ImageViewOL.frame.origin.y = 832
     
        //image at bottom right
        ImageViewOL.frame.origin.x = 330
        ImageViewOL.frame.origin.y = 0
        
        //image at the center
        ImageViewOL.frame.origin.x = 265
        ImageViewOL.frame.origin.y = 416
    }


}

