//
//  ViewController.swift
//  hello_app
//
//  Created by Errepally,Raviteja on 8/29/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func submitBTNClicked(_ sender: Any) {
        
        //Read the input from text field and assign it to a variable.
        var input = inputOL.text!
        //Print the greetings with string interpolation using input variable.
        outputOL.text = "Hello, \(input)!"
    }
}

