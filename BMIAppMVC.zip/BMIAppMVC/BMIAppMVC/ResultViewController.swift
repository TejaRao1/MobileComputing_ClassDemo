//
//  ResultViewController.swift
//  BMIAppMVC
//
//  Created by Errepally,Raviteja on 11/2/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    
    @IBOutlet weak var displayWeightOL: UILabel!
    
    
    @IBOutlet weak var displayHeightOL: UILabel!
    
    
    @IBOutlet weak var displayBMIOL: UILabel!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    var weight = ""
    var height = ""
    var bmi = 0.0
    
    var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayWeightOL.text! += weight
        displayHeightOL.text! += height
        displayBMIOL.text! += String(bmi)
        
        displayImage.image = UIImage(named: imageName)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//100 62
//120 62
//160 62
//250
