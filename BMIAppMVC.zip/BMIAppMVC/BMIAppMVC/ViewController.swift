//
//  ViewController.swift
//  BMIAppMVC
//
//  Created by Errepally,Raviteja on 11/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var weightOL: UITextField!
    
    
    @IBOutlet weak var heightOL: UITextField!
    
    var bmi = 0.0
    var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func checkBMIClicked(_ sender: Any) {
        var weight = Double(weightOL.text!)
        var height = Double(heightOL.text!)
        
        var val = weight! / (height! * height!)
        bmi = val * 703
        
        if bmi <= 18.4 {
            imageName = "underweight"
        }
        else if bmi>=18.5 && bmi<=24.9{
            imageName = "normal"
        }
        else if bmi>=25 && bmi<=39.9{
            imageName = "overweight"
        }
        else{
            imageName = "obesity"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //create a variable called transition
        var transition = segue.identifier
        
        if transition == "ResultSegue" {
            var destination = segue.destination as! ResultViewController
            
            destination.weight = weightOL.text!
            destination.height = heightOL.text!
            
            destination.bmi = bmi
            
            destination.imageName = imageName
        }
        
        
    }
    
    


}

