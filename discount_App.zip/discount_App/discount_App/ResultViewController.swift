//
//  ResultViewController.swift
//  discount_App
//
//  Created by Errepally,Raviteja on 10/31/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var EnteredAmountOL: UILabel!
    
    @IBOutlet weak var EnteredDiscountOL: UILabel!
    
    @IBOutlet weak var PriceAfterDiscountOL: UILabel!
    
    var amount = ""
    var discount = ""
    var result = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        EnteredAmountOL.text! += amount
        EnteredDiscountOL.text! += discount
        PriceAfterDiscountOL.text! += String(result)
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
