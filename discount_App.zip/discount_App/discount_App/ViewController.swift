//
//  ViewController.swift
//  discount_App
//
//  Created by Errepally,Raviteja on 10/31/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var AmountOL: UITextField!
    
    @IBOutlet weak var DiscountOL: UITextField!
    
    var result = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

  
    @IBAction func ResultOL(_ sender: Any) {
        
        var amount = Double(AmountOL.text!)
        var discount = Double(DiscountOL.text!)
        result = amount! - discount!
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "ResultSegue"{
            var destination = segue.destination as! ResultViewController
            destination.amount = AmountOL.text!
            destination.discount = DiscountOL.text!
            destination.result = result
            
        }
    }
    
}

