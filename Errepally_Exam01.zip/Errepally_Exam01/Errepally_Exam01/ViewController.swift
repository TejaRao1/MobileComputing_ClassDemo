//
//  ViewController.swift
//  Errepally_Exam01
//
//  Created by Errepally,Raviteja on 10/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var NameOL: UITextField!
    
    @IBOutlet weak var RoomTypeOL: UITextField!
    
    @IBOutlet weak var MembershipOLO: UITextField!
    
    
    @IBOutlet weak var DisplayOL: UILabel!
    
    @IBOutlet weak var ImageOL: UIImageView!
    
  
    var images = ["Single_Img", "Double_Img", "NoRoom_Img"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CalculateBTN(_ sender: Any) {
        var name = NameOL.text!
        var room = RoomTypeOL.text!
        var membership = MembershipOLO.text!
        
        if (room == "Single-Bed" || room == "single-bed" || room == "Single-bed"){
            if(membership == "Yes" || membership == "yes"){
               
                var Calculated_Price = 74.99+(74.99*16.75/100)-(74.99*5/100)
                
                var for_display = String(Calculated_Price)
                DisplayOL.text = "Dear \(name), \n you have made a reservation at Bearcat Motel  for a Single-Bed at a Price of $\(for_display) including tax"
            }
            else if (membership == "No" || membership == "no"){
               
                var Calculated_Price = 74.99+(74.99*16.75/100)
                
                var for_display = String(Calculated_Price)
                DisplayOL.text = "Dear \(name), \n you have made a reservation at Bearcat Motel  for a Single-Bed at a Price of $\(for_display) including tax"
            }
            ImageOL.image = UIImage(named: "Single_Img")
            
            
        }
        else if (room == "Double-Bed" || room == "double-bed" || room == "Double-bed"){
            if(membership == "Yes" || membership == "yes"){
               
                var Calculated_Price = 84.99+(84.99*16.75/100)-(84.99*5/100)
                
                var for_display = String(Calculated_Price)
                DisplayOL.text = "Dear \(name), \n you have made a reservation at Bearcat Motel  for a Single-Bed at a Price of $\(for_display) including tax"
            }
            else if (membership == "No" || membership == "no"){
               
                var Calculated_Price = 84.99+(84.99*16.75/100)
                
                var for_display = String(Calculated_Price)
                DisplayOL.text = "Dear \(name),\n you have made a reservation at Bearcat Motel  for a Single-Bed at a Price of $\(for_display) including tax"
            }
            ImageOL.image = UIImage(named: "Double_Img")
        }
        else{
            DisplayOL.text = "No room is available with your preference"
            ImageOL.image = UIImage(named: "NoRoom_Img")
        }
            
    }
    
    @IBAction func ResetBTN(_ sender: Any) {
        NameOL.text! = ""
        RoomTypeOL.text! = ""
        MembershipOLO.text! = ""
        DisplayOL.text = ""
        ImageOL.image = UIImage()
        
        
    }
    
    
}

