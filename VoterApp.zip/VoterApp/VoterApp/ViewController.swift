//
//  ViewController.swift
//  VoterApp
//
//  Created by Errepally,Raviteja on 9/5/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var AgeOL: UITextField!
    
    @IBOutlet weak var ResultOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CheckAgeBTN(_ sender: Any) {
        var Age = Int(AgeOL.text!)
        if(Age!>18 || Age!==18){
            ResultOL.text = "Eligible to vote👍"
        }
        else{
            ResultOL.text = "Ineligible👎"
        }
        
        
    }
    
}

