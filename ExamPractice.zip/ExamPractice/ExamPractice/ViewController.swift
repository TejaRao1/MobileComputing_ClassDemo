//
//  ViewController.swift
//  ExamPractice
//
//  Created by Errepally,Raviteja on 10/3/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InputOL: UITextField!
    

    @IBOutlet weak var ImageOL: UIImageView!
    
    @IBOutlet weak var DogNameOl: UILabel!
    
    @IBOutlet weak var DogAgeOl: UILabel!
    
    @IBOutlet weak var DogPriceOl: UILabel!
    
    var Dog_Breeds = [["dalmatian-1020790_1280","Dalmation","5","$200"],
                   ["Image 1","Husky","3","$300"],
                      ["Image","Shephard","4","$280"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitBTN(_ sender: Any) {
        var input = InputOL.text!
        
        if(input == "1"){
            ImageOL.image = UIImage(named: "dalmatian-1020790_1280")
            DogAgeOl.text = Dog_Breeds[0][2]
            DogNameOl.text = Dog_Breeds[0][1]
            DogPriceOl.text = Dog_Breeds[0][3]
        }
        else if(input == "2"){
            ImageOL.image = UIImage(named: "Image 1")
            DogAgeOl.text = Dog_Breeds[1][2]
            DogNameOl.text = Dog_Breeds[1][1]
            DogPriceOl.text = Dog_Breeds[1][3]
        }
        else{
            ImageOL.image = UIImage(named: "Image")
            DogAgeOl.text = Dog_Breeds[2][2]
            DogNameOl.text = Dog_Breeds[2][1]
            DogPriceOl.text = Dog_Breeds[2][3]
        }
        
    }
    
}

