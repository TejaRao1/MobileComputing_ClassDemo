//
//  ViewController.swift
//  HelloApp02
//
//  Created by Errepally,Raviteja on 8/29/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var inputFnameOL: UITextField!
    
    @IBOutlet weak var inputLnameOL: UITextField!
    
    
   
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
    }


    @IBOutlet weak var displayOL: UILabel!
    
    @IBAction func submitBTNclicked(_ sender: UIButton) {
        
        //Writing a variable to assign the First_name
        var F_name = inputFnameOL.text!
        var L_name = inputLnameOL.text!
        
        //Display output using string interpolation
        displayOL.text = "hello \(F_name), \(L_name)!"
        
    }
    
   
    
}

